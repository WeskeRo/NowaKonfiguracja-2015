//Bikes and ATV
class Category_608 {
	class MMT_Civ {type = "trade_any_bicycle";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class Old_bike_TK_INS_EP1 {type = "trade_any_bicycle";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class TT650_Civ {type = "trade_any_vehicle";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class TT650_Ins {type = "trade_any_vehicle";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class TT650_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class ATV_CZ_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class ATV_US_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class M1030_US_DES_EP1 {type = "trade_any_vehicle";buy[] = {3000,"Coins"};sell[] = {1000,"Coins"};};
	class Old_moto_TK_Civ_EP1 {type = "trade_any_vehicle";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class tractor {type = "trade_any_vehicle";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
};
//Buses and Vans
class Category_563 {
	class Ikarus {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {10000,"Coins"};};
	class Ikarus_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {10000,"Coins"};};
	class S1203_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {10000,"Coins"};sell[] = {5000,"Coins"};};
	class S1203_ambulance_EP1 {type = "trade_any_vehicle";buy[] = {10000,"Coins"};sell[] = {5000,"Coins"};};
};
//Cargo Trucks
class Category_564 {
	class Ural_CDF {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class Ural_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class Ural_UN_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class V3S_Open_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class V3S_Open_TK_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class Kamaz {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class MTVR_DES_EP1 {type = "trade_any_vehicle";buy[] = {45000,"Coins"};sell[] = {20000,"Coins"};};
	class V3S_Civ {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class V3S_RA_TK_GUE_EP1_DZE {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class V3S_TK_EP1_DZE {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class UralCivil_DZE {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class UralCivil2_DZE {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class KamazOpen_DZE {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class MTVR {type = "trade_any_vehicle";buy[] = {45000,"Coins"};sell[] = {20000,"Coins"};};
};
//Fuel Trucks
class Category_492 {
	class KamazRefuel_DZ {type = "trade_any_vehicle";buy[] = {70000,"Coins"};sell[] = {30000,"Coins"};};
	class MtvrRefuel_DES_EP1_DZ {type = "trade_any_vehicle";buy[] = {75000,"Coins"};sell[] = {30000,"Coins"};};
	class UralRefuel_TK_EP1_DZ {type = "trade_any_vehicle";buy[] = {70000,"Coins"};sell[] = {30000,"Coins"};};
	class V3S_Refuel_TK_GUE_EP1_DZ {type = "trade_any_vehicle";buy[] = {70000,"Coins"};sell[] = {30000,"Coins"};};
	class MtvrRefuel_DZ {type = "trade_any_vehicle";buy[] = {75000,"Coins"};sell[] = {30000,"Coins"};};
};
//Military Unarmed
class Category_491 {
	class HMMWV_DES_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class HMMWV_DZ {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};	
	class HMMWV_M1035_DES_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class HMMWV_Ambulance {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class HMMWV_Ambulance_CZ_DES_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};	
	class LandRover_CZ_EP1 {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class LandRover_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};	
	class GAZ_Vodnik_MedEvac {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {10000,"Coins"};};
};
//Trucks
class Category_495 {
	class hilux1_civil_3_open_EP1 {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class datsun1_civil_3_open {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class hilux1_civil_1_open {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class datsun1_civil_2_covered {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class datsun1_civil_1_open {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class hilux1_civil_2_covered {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
};
//Used Cars
class Category_585 {
	class Skoda {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class SkodaBlue {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class SkodaGreen {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class SkodaRed {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class VolhaLimo_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class Volha_1_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class Volha_2_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class VWGolf {type = "trade_any_vehicle";buy[] = {5000,"Coins"};sell[] = {2000,"Coins"};};
	class car_hatchback {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class car_sedan {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class GLT_M300_LT {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class GLT_M300_ST {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class Lada1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class Lada1_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class Lada2 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class Lada2_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class LadaLM {type = "trade_any_vehicle";buy[] = {5000,"Coins"};sell[] = {2000,"Coins"};};
};
//Utility Vehicles
class Category_565 {
	class SUV_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Blue {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Charcoal {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Green {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Orange {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Pink {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Red {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Silver {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_White {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Yellow {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class SUV_Camo {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class UAZ_CDF {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class UAZ_INS {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class UAZ_RU {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class UAZ_Unarmed_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class UAZ_Unarmed_TK_EP1 {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class UAZ_Unarmed_UN_EP1 {type = "trade_any_vehicle";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class policecar {type = "trade_any_vehicle";buy[] = {10000,"Coins"};sell[] = {4000,"Coins"};};
};
//Sport Cars
class Category_697 {
	class 350z {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_red {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_kiwi {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_black {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_silver {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_green {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_blue {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_white {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_pink {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_yellow {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_gold {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_mod {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_ruben {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_v {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class 350z_city {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	/*
	class civcar {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class Civcarbu {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class civcarbl {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class civcarre {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class civcarge {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class civcarwh {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class civcarsl {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class Copcar {type = "trade_any_vehicle";buy[] = {35000,"Coins"};sell[] = {17000,"Coins"};};
	class Copcarhw {type = "trade_any_vehicle";buy[] = {35000,"Coins"};sell[] = {17000,"Coins"};};
	class Copcarswat {type = "trade_any_vehicle";buy[] = {35000,"Coins"};sell[] = {17000,"Coins"};};
	*/
};
