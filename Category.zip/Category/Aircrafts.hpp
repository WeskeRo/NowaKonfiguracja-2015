//Air planes
class Category_517 {
	class AN2_DZ {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	//class An2_1_TK_CIV_EP1 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class GNT_C185U {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class GNT_C185 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class GNT_C185R {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	class GNT_C185C {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	//class CYBP_Camel_us {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	//class CYBP_Camel_rus {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {20000,"Coins"};};
	//class CYBP_Camel_civ {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	class MV22_DZ {type = "trade_any_vehicle";buy[] = {500000,"Coins"};sell[] = {100000,"Coins"};};
	class C130J_US_EP1_DZ {type = "trade_any_vehicle";buy[] = {500000,"Coins"};sell[] = {200000,"Coins"};};
};
//Helicopter Unarmed
class Category_519 {
	class AH6X_DZ {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {15000,"Coins"};};
	class MH6J_DZ {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	class CSJ_GyroC {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class CSJ_GyroCover {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class CSJ_GyroP {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class Ka137_PMC {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class Pchela1T {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class Mi17_Civilian_DZ {type = "trade_any_vehicle";buy[] = {100000,"Coins"};sell[] = {80000,"Coins"};};
	class BAF_Merlin_DZE {type = "trade_any_vehicle";buy[] = {300000,"Coins"};sell[] = {150000,"Coins"};};
	class CH53_DZE {type = "trade_any_vehicle";buy[] = {400000,"Coins"};sell[] = {150000,"Coins"};};
	//class AW159_Lynx_BAF {type = "trade_any_vehicle";buy[] = {200000,"Coins"};sell[] = {100000,"Coins"};};
	class pook_H13_medevac {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_CDF {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_TAK {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_INS {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_UNO {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_PMC {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_GUE {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_CIV {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_medevac_CIV_RU {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_white {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_slate {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_black {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_yellow {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_ru {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_ru_white {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_ru_slate {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_ru_black {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class pook_H13_civ_ru_yellow {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
};
