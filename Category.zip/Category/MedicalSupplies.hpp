//Chemlites/Flares
class Category_666 {
	class HandChemBlue {type = "trade_items";buy[] = {200,"Coins"};sell[] = {200,"Coins"};};
	class HandChemGreen {type = "trade_items";buy[] = {200,"Coins"};sell[] = {200,"Coins"};};
	class HandChemRed {type = "trade_items";buy[] = {200,"Coins"};sell[] = {200,"Coins"};};
	class FlareGreen_M203 {type = "trade_items";buy[] = {200,"Coins"};sell[] = {200,"Coins"};};
	class FlareWhite_M203 {type = "trade_items";buy[] = {200,"Coins"};sell[] = {200,"Coins"};};
	class HandRoadFlare {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
};
//Medical Supplies
class Category_665 {
	class ItemAntibiotic {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
	class ItemBandage {type = "trade_items";buy[] = {300,"Coins"};sell[] = {300,"Coins"};};
	class ItemBloodbag {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class ItemEpinephrine {type = "trade_items";buy[] = {300,"Coins"};sell[] = {300,"Coins"};};
	class ItemHeatPack {type = "trade_items";buy[] = {300,"Coins"};sell[] = {300,"Coins"};};
	class ItemMorphine {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {500,"Coins"};};
	class ItemPainkiller {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
};
//Smoke Grenades
class Category_668 {
	class SmokeShell {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class SmokeShellGreen {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class SmokeShellRed {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
};
