class Category_700 {
	class ori_scrapTank {type = "trade_any_vehicle";buy[] = {160000,"Coins"};sell[] = {80000,"Coins"};};
	class ori_titanic {type = "trade_any_vehicle";buy[] = {100000,"Coins"};sell[] = {50000,"Coins"};};
	class ori_vil_originsmod_volvo_fl290 {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class ori_excavator {type = "trade_any_vehicle";buy[] = {18000,"Coins"};sell[] = {9000,"Coins"};};
	class ori_survivorBus {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	class ori_vil_originsmod_lublin_truck {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};	
	class ori_vil_originsmod_truck_civ {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	class ori_p85_originsmod_cucv_pickup {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	class ori_originsmod_pickupoldfuel {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {40000,"Coins"};};
	class ori_ScrapBuggy {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class ori_rth_originsmod_bathmobile {type = "trade_any_vehicle";buy[] = {10000,"Coins"};sell[] = {5000,"Coins"};};
	class ori_p85_originsmod_CUCV {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_vil_lada_2105_rust {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};	
	class ori_poldek {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	class ori_poldek_black {type = "trade_any_vehicle";buy[] = {60000,"Coins"};sell[] = {30000,"Coins"};};
	//NEW
	class ori_ZAZ968M {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_taviander {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_buchanka {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_m3 {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_maniac {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {25000,"Coins"};};	
	class ori_KaTransp {type = "trade_any_vehicle";buy[] = {40000,"Coins"};sell[] = {25000,"Coins"};};
};

class Category_699 {
	class ori_pragaCopter_yellow {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_pragaCopter_green {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	class vil_ori_autogyro {type = "trade_any_vehicle";buy[] = {30000,"Coins"};sell[] = {15000,"Coins"};};
	class ori_dc3 {type = "trade_any_vehicle";buy[] = {400000,"Coins"};sell[] = {200000,"Coins"};};
	class ori_gunship_helicopter {type = "trade_any_vehicle";buy[] = {500000,"Coins"};sell[] = {250000,"Coins"};};
};
class Category_701 {
	class ori_transit {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	class ori_originsmod_pickupold {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
};
class Category_702 {
	class ori_smallRaft {type = "trade_any_vehicle";buy[] = {10000,"Coins"};sell[] = {5000,"Coins"};};
	class ori_bigRaft {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
	class ori_submarine {type = "trade_any_vehicle";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	//NEW
	class ori_ScrapRaft {type = "trade_any_vehicle";buy[] = {20000,"Coins"};sell[] = {10000,"Coins"};};
};
class Category_703 {
	//bandit houses
	class ItemSodaSmashtEmpty {type = "trade_items";buy[] ={250000,"Coins"};sell[] ={100000,"Coins"};};
	class ItemSodaDrwasteEmpty {type = "trade_items";buy[] ={300000,"Coins"};sell[] ={125000,"Coins"};};
	class ItemSodaLemonadeEmpty {type = "trade_items";buy[] ={350000,"Coins"};sell[] ={150000,"Coins"};};
	//hero houses
	class ItemSodaMtngreenEmpty {type = "trade_items";buy[] ={200000,"Coins"};sell[] ={100000,"Coins"};};
	class ItemSodaR4z0rEmpty {type = "trade_items";buy[] ={250000,"Coins"};sell[] ={125000,"Coins"};};
	class ItemSodaClaysEmpty {type = "trade_items";buy[] ={300000,"Coins"};sell[] ={150000,"Coins"};};
	//garages
	class ItemSodaLvgEmpty {type = "trade_items";buy[] ={200000,"Coins"};sell[] ={75000,"Coins"};};
	class ItemSodaMzlyEmpty {type = "trade_items";buy[] ={300000,"Coins"};sell[] ={75000,"Coins"};};
	//stronghold
	class ItemSodaRabbitEmpty {type = "trade_items";buy[] ={950000,"Coins"};sell[] ={300000,"Coins"};};
};