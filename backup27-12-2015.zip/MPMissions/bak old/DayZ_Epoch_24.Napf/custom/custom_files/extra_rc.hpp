class ExtraRc {
	class ItemGPS {
		class shit {
            text = "Take a Dump";
            script = "execVM 'Custom\shit.sqf'";
        };
    };
  class ItemRadio {
     class GroupManagement {
        text = "Group Management";
        script = "execVM 'dzgm\loadGroupManagement.sqf'";
     };
  };
};