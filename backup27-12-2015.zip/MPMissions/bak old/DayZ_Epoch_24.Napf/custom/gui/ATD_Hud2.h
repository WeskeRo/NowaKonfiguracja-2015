#define CT_STATIC 0
#define ST_LEFT           0x00
#define ST_PICTURE        48