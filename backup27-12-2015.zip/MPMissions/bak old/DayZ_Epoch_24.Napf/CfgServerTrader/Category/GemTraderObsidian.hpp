class Category_998 {
	class GAZ_Vodnik_HMG {
		type = "trade_any_vehicle_old";
		buy[] = {12,"ItemObsidian"};
		sell[] = {2,"ItemObsidian"};
	};
	class ItemTNK {
		type = "trade_items_old";
		buy[] = {2,"ItemObsidian"};
		sell[] = {1,"ItemObsidian"};
	};
	class ItemLRK {
		type = "trade_items_old";
		buy[] = {2,"ItemObsidian"};
		sell[] = {1,"ItemObsidian"};
	};
	class ItemORP {
		type = "trade_items_old";
		buy[] = {2,"ItemObsidian"};
		sell[] = {1,"ItemObsidian"};
	};
	class ItemAVE {
		type = "trade_items_old";
		buy[] = {2,"ItemObsidian"};
		sell[] = {1,"ItemObsidian"};
	};
};