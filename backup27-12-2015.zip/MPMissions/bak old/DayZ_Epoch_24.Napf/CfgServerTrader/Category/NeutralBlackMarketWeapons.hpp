class Category_526 {
	class Saiga12K {
		type = "trade_weapons";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class m8_compact {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class m8_sharpshooter {
		type = "trade_weapons";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class m8_holo_sd {
		type = "trade_weapons";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class m8_carbine {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
	class VSS_vintorez {
		type = "trade_weapons";
		buy[] ={7000,"Coins"};
		sell[] ={3500,"Coins"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class M8_SAW {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MG36 {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class RPK_74 {
		type = "trade_weapons";
		buy[] ={15000,"Coins"};
		sell[] ={7500,"Coins"};
	};
	class M60A4_EP1_DZE {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class m240_scoped_EP1_DZE {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class M249_m145_EP1_DZE {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MG36_camo {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class bizon {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M4A1_HWS_GL_SD_Camo {
		type = "trade_weapons";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class KSVK_DZE {
		type = "trade_weapons";
		buy[] ={30000,"Coins"};
		sell[] ={15000,"Coins"};
	};
};
