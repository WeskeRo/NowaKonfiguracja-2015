class Category_999 {
	class AH6J_EP1 {
		type = "trade_any_vehicle_old";
		buy[] = {12,"ItemRuby"};
		sell[] = {2,"ItemRuby"};
	};
};