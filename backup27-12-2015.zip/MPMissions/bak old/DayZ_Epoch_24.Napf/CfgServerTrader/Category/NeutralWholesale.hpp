class Category_636 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] ={18000,"Coins"};
		sell[] ={18000,"Coins"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemWoodWall {
		type = "trade_items";
		buy[] ={3500,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemWoodWallLg {
		type = "trade_items";
		buy[] ={4300,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemWoodFloor {
		type = "trade_items";
		buy[] ={4100,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemWoodLadder {
		type = "trade_items";
		buy[] ={1300,"Coins"};
		sell[] ={500,"Coins"};
	};
	class ItemWoodStairs {
		type = "trade_items";
		buy[] ={1300,"Coins"};
		sell[] ={500,"Coins"};
	};
	class cinder_wall_kit {
		type = "trade_items";
		buy[] ={41000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class cinder_door_kit {
		type = "trade_items";
		buy[] ={51000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class cinder_garage_kit {
		type = "trade_items";
		buy[] ={51000,"Coins"};
		sell[] ={15000,"Coins"};
	};
	class metal_floor_kit {
		type = "trade_items";
		buy[] ={14000,"Coins"};
		sell[] ={5000,"Coins"};
	};	
};
