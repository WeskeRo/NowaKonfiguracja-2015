class Category_512 {
		class CH_47F_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class UH1H_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Mi17_DZE {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Mi17_CDF {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Mi17_Ins {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class UH60M_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class UH1Y_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class MH60S_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class UH1H_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={100000,"Coins"};	
	};
	class Mi17_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	
};		