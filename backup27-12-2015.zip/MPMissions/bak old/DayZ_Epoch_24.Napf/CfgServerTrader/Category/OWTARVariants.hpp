class Category_1003 {

class RH_ctar21 {type = "trade_weapons";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
class RH_ctar21glacog {type = "trade_weapons";buy[] = {4600,"Coins"};sell[] = {2300,"Coins"};};
class RH_ctar21m {type = "trade_weapons";buy[] = {4200,"Coins"};sell[] = {2200,"Coins"};};
class RH_ctar21mgl {type = "trade_weapons";buy[] = {4600,"Coins"};sell[] = {2300,"Coins"};};
};