class Category_605 {
	class SVD_CAMO {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class M40A3 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
	class M14_EP1 {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class huntingrifle {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M4SPR {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class M24 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
};
class Category_640 {
	class SVD_CAMO {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class M40A3 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
	class M14_EP1 {
		type = "trade_weapons";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class huntingrifle {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M4SPR {
		type = "trade_weapons";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] ={11000,"Coins"};
		sell[] ={5500,"Coins"};
	};
	class M24 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
	class M110_NVG_EP1 {
		type = "trade_weapons";
		buy[] ={12000,"Coins"};
		sell[] ={6000,"Coins"};
	};
};
