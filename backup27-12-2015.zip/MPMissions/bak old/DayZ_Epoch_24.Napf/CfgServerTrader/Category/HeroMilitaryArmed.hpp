class Category_562 {
	class HMMWV_M998A2_SOV_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class HMMWV_M1151_M2_CZ_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={216000,"Coins"};
		sell[] ={108000,"Coins"};
	};
	class LandRover_Special_CZ_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class LandRover_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class UAZ_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={150000,"Coins"};
		sell[] ={75000,"Coins"};
	};
	class GAZ_Vodnik_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class HMMWV_M2_USArmy {
		type = "trade_any_vehicle";
		buy[] ={250000,"Coins"};
		sell[] ={125000,"Coins"};
	};
	class HMMWV_Mk19_USArmy {
		type = "trade_any_vehicle";
		buy[] ={250000,"Coins"};
		sell[] ={125000,"Coins"};
	};	
};