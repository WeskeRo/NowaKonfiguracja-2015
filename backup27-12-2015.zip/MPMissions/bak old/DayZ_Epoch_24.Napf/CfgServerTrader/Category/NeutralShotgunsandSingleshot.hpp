class Category_607 {
	class Winchester1866 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class MR43 {
		type = "trade_weapons";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class Crossbow_DZ {
		type = "trade_weapons";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class M1014 {
		type = "trade_weapons";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class Remington870_lamp {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class LeeEnfield {
		type = "trade_weapons";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
};
class Category_641 {
	class Winchester1866 {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class MR43 {
		type = "trade_weapons";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class Crossbow_DZ {
		type = "trade_weapons";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class M1014 {
		type = "trade_weapons";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class Remington870_lamp {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class LeeEnfield {
		type = "trade_weapons";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
};
