class Category_498 {
	class ItemSodaR4z0r {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class ItemSodaCoke {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemSodaMdew {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemSodaOrangeSherbet {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
        class ItemSodaPepsi {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
        class ItemSodaRbull {
		type = "trade_items";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class ItemWaterbottle {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemWaterbottleUnfilled {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
class Category_633 {
	class ItemSodaR4z0r {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class ItemSodaCoke {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemSodaMdew {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemSodaOrangeSherbet {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
        class ItemSodaPepsi {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
        class ItemSodaRbull {
		type = "trade_items";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class ItemWaterbottle {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemWaterbottleUnfilled {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};