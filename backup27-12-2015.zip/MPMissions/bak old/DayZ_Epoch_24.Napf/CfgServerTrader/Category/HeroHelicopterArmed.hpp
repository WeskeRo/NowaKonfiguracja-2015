class Category_493 {
	class CH_47F_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class UH1H_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Mi17_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Mi17_CDF {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class Mi17_Ins {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class UH60M_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class UH1Y_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class MH60S_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class AH6J_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={200000,"Coins"};
	};
	class pook_H13_gunship_CDF {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class Ka137_MG_PMC {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={150000,"Coins"};	
	};	
};	