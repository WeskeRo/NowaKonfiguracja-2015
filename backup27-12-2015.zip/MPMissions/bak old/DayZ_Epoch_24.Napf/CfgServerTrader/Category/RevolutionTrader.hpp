class Category_693 {

		class A10 {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {500000,"Coins"};
		};
		
		class F35B {
		type = "trade_any_vehicle";
		buy[] = {7000000,"Coins"};
		sell[] = {600000,"Coins"};
		};

		class Su34 {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {400000,"Coins"};
		};

		class Su39 {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {300000,"Coins"};
		};

		class Su25_Ins {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {300000,"Coins"};
		};	
		
		class L39_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {400000,"Coins"};
		};	
		
};



class Category_694 {

		class RPG7V {
		type = "trade_weapons";
		buy[] = {100000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
		class M32_EP1 {
		type = "trade_weapons";
		buy[] = {200000,"Coins"};
		sell[] = {10000,"Coins"};
		};
		
		class DMR_DZ {
		type = "trade_weapons";
		buy[] = {30000,"Coins"};
		sell[] = {5000,"Coins"};
		};
		
		class DMR {
		type = "trade_weapons";
		buy[] = {30000,"Coins"};
		sell[] = {5000,"Coins"};
		};
		     
	    class DMR_SKN {
		type = "trade_weapons";
		buy[] = {30000,"Coins"};
		sell[] = {5000,"Coins"};
		};	
		
		class BAF_AS50_scoped_DZ {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class m107_SKN {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class BAF_AS50_TWS {
		type = "trade_weapons";
		buy[] = {1000000,"Coins"};
		sell[] = {50000,"Coins"};
		};	
		
		class BAF_AS50_TWS_Large {
		type = "trade_weapons";
		buy[] = {1000000,"Coins"};
		sell[] = {50000,"Coins"};
		};	
		
		class PMC_AS50_TWS_Large {
		type = "trade_weapons";
		buy[] = {1000000,"Coins"};
		sell[] = {50000,"Coins"};
		};	
		
		class PMC_AS50_scoped_Large {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class BAF_AS50_scoped_Large {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class m107 {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class M107_DZ {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class m107_TWS_EP1 {
		type = "trade_weapons";
		buy[] = {1000000,"Coins"};
		sell[] = {50000,"Coins"};
		};	
		
		class m107_TWS_EP1_DZ {
		type = "trade_weapons";
		buy[] = {1000000,"Coins"};
		sell[] = {50000,"Coins"};
		};	
		
		class vil_CG84T {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};	
		
		class vil_Panzerfaust3 {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};
		
		class Vil_RPO_A {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};
		
		class BAF_NLAW_Launcher {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};
		
		class SMAW {
		type = "trade_weapons";
		buy[] = {400000,"Coins"};
		sell[] = {30000,"Coins"};
		};
		
};


class Category_695 {
		class PG7V {
		type = "trade_items";
		buy[] = {70000,"Coins"};
		sell[] = {20000,"Coins"};
		};
		
		class PG7VL {
		type = "trade_items";
		buy[] = {80000,"Coins"};
		sell[] = {20000,"Coins"};
		};
		
		class PG7VR {
		type = "trade_items";
		buy[] = {90000,"Coins"};
		sell[] = {20000,"Coins"};
		};
		
		class OG7 {
		type = "trade_items";
		buy[] = {80000,"Coins"};
		sell[] = {20000,"Coins"};
		};
		
	class 6Rnd_HE_M203 {
		type = "trade_items";
		buy[] = {50000,"Coins"};
		sell[] = {20000,"Coins"};
		};
		
	class 6Rnd_FlareWhite_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_FlareGreen_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_FlareRed_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_FlareYellow_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_Smoke_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_SmokeRed_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_SmokeGreen_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};
		
	class 6Rnd_SmokeYellow_M203 {
		type = "trade_items";
		buy[] = {1000,"Coins"};
		sell[] = {500,"Coins"};
		};	

	class 5Rnd_127x99_AS50 {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {1000,"Coins"};
		};		
		
	class 10Rnd_127x99_m107 {
		type = "trade_items";
		buy[] = {4000,"Coins"};
		sell[] = {1000,"Coins"};
		};	
	
	class Vil_CG_HEAT {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
	class Vil_CG_HEDP {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class Vil_CG_84 {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class Vil_SHMEL_FTW {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class Vil_PZF3_S_HEAT {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class Vil_PZF3_T_HEAT {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};	
		
	class Vil_PZF3_B_HEDP {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {75000,"Coins"};
		};

	class NLAW {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
	class NLAW_Big {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class SMAW_HEAA {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class SMAW_HEDP {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class SMAW_HEAA_Big {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class SMAW_HEDP_Big {
		type = "trade_items";
		buy[] = {250000,"Coins"};
		sell[] = {25000,"Coins"};
		};

	class Stinger {
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
};



class Category_696 {

		class HMMWV_M998_crows_M2_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {1600000,"Coins"};
		sell[] = {200000,"Coins"};
		};
		
		class M1133_MEV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {1000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class BRDM2_HQ_TK_GUE_EP1 {
		type = "trade_any_vehicle";
		buy[] = {1600000,"Coins"};
		sell[] = {200000,"Coins"};
		};
		
		class M113Ambul_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] = {800000,"Coins"};
		sell[] = {125000,"Coins"};
		};
		
		class BTR90 {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {300000,"Coins"};
		};
		
		class LAV25_DZ {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {300000,"Coins"};
		};
		
		class M1A1_US_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] =  {6000000,"Coins"};
		sell[] = {400000,"Coins"};};
		
		class BTR60_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] =  {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};

		class HMMWV_Avenger_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] =  {3000000,"Coins"};
		sell[] = {175000,"Coins"};
		};

		class M1126_ICV_M2_EP1 {
		type = "trade_any_vehicle";
		buy[] = {1800000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class Stinger_Pod_US_EP1 {
		type = "trade_any_vehicle";
		buy[] = {3500000,"Coins"};
		sell[] = {200000,"Coins"};
		};
	
		class BMP2_HQ_CDF {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {200000,"Coins"};
		};
		
		class T72_INS {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {350000,"Coins"};
		};	
		
		class M1A2_TUSK_MG {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {400000,"Coins"};
		};	
		
		class T34 {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {250000,"Coins"};
		};
		
		class BMP3 {
		type = "trade_any_vehicle";
		buy[] = {4000000,"Coins"};
		sell[] = {250000,"Coins"};
		};
		
		class T55_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {275000,"Coins"};
		};
		
		class ZU23_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {3000000,"Coins"};
		sell[] = {200000,"Coins"};
		};
		
		class T90 {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {250000,"Coins"};
		};
		
		class AAV {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {275000,"Coins"};
		};
		
		class BAF_L2A1_Tripod_W {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {100000,"Coins"};
		};
		
		class DSHkM_Mini_TriPod {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class KORD_high {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class M2StaticMG {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class MK19_TriPod {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class SPG9_CDF {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
		class M2HD_mini_TriPod {
		type = "trade_any_vehicle";
		buy[] = {2000000,"Coins"};
		sell[] = {150000,"Coins"};
		};
		
};

class Category_697 {

		class AW159_Lynx_BAF {
		type = "trade_any_vehicle";
		buy[] = {3300000,"Coins"};
		sell[] = {200000,"Coins"};
		};
		
		class Ka60_GL_PMC {
		type = "trade_any_vehicle";
		buy[] = {2500000,"Coins"};
		sell[] = {300000,"Coins"};
		};

		class Mi171Sh_rockets_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {3400000,"Coins"};
		sell[] = {250000,"Coins"};
		};

		class Mi24_D_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {250000,"Coins"};
		};

		class AH64D_EP1 {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {250000,"Coins"};
		};

		class AH1Z {
		type = "trade_any_vehicle";
		buy[] = {7000000,"Coins"};
		sell[] = {380000,"Coins"};
		};

		class AH64D {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {350000,"Coins"};
		};

		class Mi17_CDF {
		type = "trade_any_vehicle";
		buy[] = {500000,"Coins"};
		sell[] = {250000,"Coins"};
		};

		class Ka52 {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {300000,"Coins"};
		};

		class Ka52Black {
		type = "trade_any_vehicle";
		buy[] = {6000000,"Coins"};
		sell[] = {300000,"Coins"};
		};

		class Ka137_MG_PMC {
		type = "trade_any_vehicle";
		buy[] = {1500000,"Coins"};
		sell[] = {250000,"Coins"};
		};
		
};

class Category_698 {


		class ItemComboLock {
		type = "trade_items";
		buy[] = {10000,"Coins"};
		sell[] = {7500,"Coins"};
		};

		class ChainSawR {
		type = "trade_weapons";
		buy[] = {20000,"Coins"};
		sell[] = {5000,"Coins"};
		};
		
		class m240_nest_kit {
		type = "trade_items";
		buy[] = {70000,"Coins"};
		sell[] = {10000,"Coins"};
		};
		
		class ItemKiloHemp {
		type = "trade_items";
		buy[] = {10000,"Coins"};
		sell[] = {1000,"Coins"};
		};

};

class Category_699 {

		class BAF_ied_v1 {
		type = "trade_items";
		buy[] = {200000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
		class BAF_ied_v2 {
		type = "trade_items";
		buy[] = {200000,"Coins"};
		sell[] = {25000,"Coins"};
		};

		class BAF_ied_v3 {
		type = "trade_items";
		buy[] = {200000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
		class BAF_ied_v4 {
		type = "trade_items";
		buy[] = {200000,"Coins"};
		sell[] = {25000,"Coins"};
		};
		
		class Mine {
		type = "trade_items";
		buy[] = {100000,"Coins"};
		sell[] = {10000,"Coins"};
		};
		
};

class Category_702 {

		class MtvrReammo_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {1000000,"Coins"};
		sell[] = {100000,"Coins"};
		};
		
		class UralReammo_CDF {
		type = "trade_any_vehicle";
		buy[] = {1000000,"Coins"};
		sell[] = {100000,"Coins"};
		};

		class KamazReammo {
		type = "trade_any_vehicle";
		buy[] = {1000000,"Coins"};
		sell[] = {100000,"Coins"};
		};
		
		class V3S_Reammo_TK_GUE_EP1 {
		type = "trade_any_vehicle";
		buy[] = {1000000,"Coins"};
		sell[] = {100000,"Coins"};
		};
		
		class SUV_PMC {
		type = "trade_any_vehicle";
		buy[] = {5000000,"Coins"};
		sell[] = {200000,"Coins"};
		};
		
};
