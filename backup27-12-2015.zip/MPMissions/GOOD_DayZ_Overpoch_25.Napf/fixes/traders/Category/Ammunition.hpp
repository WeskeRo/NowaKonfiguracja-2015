//Assault Rifle Ammo
class Category_609 {
	class 30Rnd_556x45_Stanag {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_762x51_FNFAL {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_545x39_AK {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_762x39_AK47 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_762x39_SA58 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_762x51_B_SCAR {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
};
//Light Machine Gun Ammo
class Category_610 {
	class 100Rnd_762x51_M240 {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class 200Rnd_556x45_M249 {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
	class 100Rnd_762x54_PK {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
};
//Pistol Ammo
class Category_611 {
	class 15Rnd_9x19_M9 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 15Rnd_9x19_M9SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 17Rnd_9x19_glock17 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 6Rnd_45ACP {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 7Rnd_45ACP_1911 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 8Rnd_9x18_Makarov {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 8Rnd_9x18_MakarovSD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
};
//Shotguns and Single-shot Ammo
class Category_613 {
	class 15Rnd_W1866_Slug {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 2Rnd_shotgun_74Pellets {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 2Rnd_shotgun_74Slug {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 8Rnd_B_Beneli_74Slug {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class 8Rnd_B_Beneli_Pellets {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
	class WoodenArrow {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class Quiver {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 10x_303 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
};
//Sniper Rifle Ammo
class Category_614 {
	class 20Rnd_762x51_DMR {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {500,"Coins"};};
	class 10Rnd_762x54_SVD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 5Rnd_762x51_M24 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {500,"Coins"};};
	class 5x_22_LR_17_HMR {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 5Rnd_127x108_KSVK {type = "trade_items";buy[] = {1500,"Coins"};sell[] = {500,"Coins"};};
	class 5Rnd_86x70_L115A1 {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
	class 10Rnd_9x39_SP5_VSS {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_9x39_SP5_VSS {type = "trade_items";buy[] = {3000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_10Rnd_SVDK {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {500,"Coins"};};
};
//Submachine Gun Ammo
class Category_612 {
	class 30rnd_9x19_MP5 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_9x19_MP5SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_9x19_UZI {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 64Rnd_9x19_SD_Bizon {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_9x19_UZI_SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_B_765x17_Ball {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
};
//Mixed Ammo
class Category_698 {
	class gms_k98_mag {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_556x45_Stanag {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_556x45_G36 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_545x39_AK {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class VIL_30Rnd_556x45_AK {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_7Rnd_50_AE {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_6Rnd_44_Mag {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_6Rnd_357_Mag {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_13Rnd_9x19_bhp {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_15Rnd_9x19_usp {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_8Rnd_9x19_P38 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_7Rnd_32cal_ppk {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_8Rnd_9x19_Mk {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_8Rnd_9x19_Mksd {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_15Rnd_9x19_uspsd {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_12Rnd_45cal_usp {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_8Rnd_45cal_m1911 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_8Rnd_762_tt33 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_10Rnd_22LR_mk2 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_20Rnd_9x19_M93 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 15Rnd_9x19_M9 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class 15Rnd_9x19_M9SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_19Rnd_9x19_g18 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_17Rnd_9x19_g17 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_17Rnd_9x19_g17SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_20Rnd_32cal_vz61 {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_30Rnd_9x19_tec {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
	class RH_32Rnd_9x19_Muzi {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_556x45_StanagSD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_20Rnd_762x51_hk417 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class RH_20Rnd_762x51_SD_hk417 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_762x51_DMR {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {500,"Coins"};};
	class USSR_5Rnd_408 {type = "trade_items";buy[] = {3000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_30Rnd_680x43_ACR {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_30Rnd_680x43_ACR_SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_7Rnd_338Lapua_MSR_NT {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_7Rnd_338Lapua_MSR_NT_SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_20Rnd_762x51_PMAG_NT {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_20Rnd_762x51_PMAG_NT_SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_5Rnd_300Win_XM2010_NT {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FHQ_rem_5Rnd_300Win_XM2010_NT_SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_10Rnd_762x39_SKS {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_8Rnd_TT {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_9x18_aps {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_9x18_apsSD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_17Rnd_9x19_PYA {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_9x39_SP6ns_OC {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_9x39_SP6_VAL {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_9x39_SP6_OC {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_45Rnd_545x39_AK {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 30Rnd_545x39_AKSD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_10Rnd_Mauser {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_10Rnd_PSL {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 10Rnd_762x54_SVD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_10Rnd_762x54_SV {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_bhp_mag {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 17Rnd_9x19_glock17 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_usp45_mag {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_usp45sd_mag {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_32Rnd_uzi {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_32Rnd_UZI_SD {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_762x51_G3 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_762x51_FNFAL {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_556x45_SG {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_20Rnd_556x45_IN {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class Vil_30Rnd_556x45_HK {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class Vil_35Rnd_556x45_G {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 100Rnd_762x51_M240 {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class 100Rnd_762x54_PK {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_40Rnd_762x39_AK47 {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_75Rnd_762x39_AK47 {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class vil_100Rnd_762x39_RPD {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class 200Rnd_556x45_M249 {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
	class 100Rnd_556x45_BetaCMag {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class 75Rnd_545x39_RPK {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_B_AA12_Pellets {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class 20Rnd_B_AA12_74Slug {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};	
};