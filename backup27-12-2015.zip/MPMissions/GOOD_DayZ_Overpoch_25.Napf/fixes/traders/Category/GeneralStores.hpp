//Backpacks
class Category_632 {
	class DZ_Patrol_Pack_EP1 {type = "trade_backpacks";buy[] = {800,"Coins"};sell[] = {800,"Coins"};};
	class CZ_VestPouch_EP1 {type = "trade_backpacks";buy[] = {300,"Coins"};sell[] = {300,"Coins"};};
	class DZ_ALICE_Pack_EP1 {type = "trade_backpacks";buy[] = {1200,"Coins"};sell[] = {1200,"Coins"};};
	class DZ_Assault_Pack_EP1 {type = "trade_backpacks";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class DZ_Backpack_EP1 {type = "trade_backpacks";buy[] = {8000,"Coins"};sell[] = {4000,"Coins"};};
	class DZ_British_ACU {type = "trade_backpacks";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
	class DZ_CivilBackpack_EP1 {type = "trade_backpacks";buy[] = {6000,"Coins"};sell[] = {4000,"Coins"};};
	class DZ_Czech_Vest_Puch {type = "trade_backpacks";buy[] = {300,"Coins"};sell[] = {300,"Coins"};};
	class DZ_TK_Assault_Pack_EP1 {type = "trade_backpacks";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class DZ_TerminalPack_EP1 {type = "trade_backpacks";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class DZ_GunBag_EP1 {type = "trade_backpacks";buy[] = {6000,"Coins"};sell[] = {3000,"Coins"};};
};
//Clothes
class Category_631 {
	class Skin_Rocker2_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_SurvivorW2_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Functionary1_EP1_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Haris_Press_EP1_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Priest_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_SurvivorWurban_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_SurvivorWcombat_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_SurvivorWdesert_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Survivor2_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Rocker1_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Rocker3_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_RU_Policeman_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Pilot_EP1_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_Rocker4_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class Skin_SurvivorW3_DZ {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
};
//Cooked Meats
class Category_634 {
	class FoodbaconCooked {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FoodbeefCooked {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FoodchickenCooked {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FoodmuttonCooked {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class FoodrabbitCooked {type = "trade_items";buy[] = {1200,"Coins"};sell[] = {1000,"Coins"};};
	class ItemTroutCooked {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class ItemSeaBassCooked {type = "trade_items";buy[] = {3000,"Coins"};sell[] = {1000,"Coins"};};
	class ItemTunaCooked {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {1000,"Coins"};};
};
//Drinks
class Category_633 {
	class ItemSodaCoke {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class ItemSodaPepsi {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class ItemSodaMdew {type = "trade_items";buy[] = {6000,"Coins"};sell[] = {3000,"Coins"};};
	class ItemWaterbottleUnfilled {type = "trade_items";buy[] = {800,"Coins"};sell[] = {800,"Coins"};};
	class ItemSodaRbull {type = "trade_items";buy[] = {6000,"Coins"};sell[] = {3000,"Coins"};};
	class ItemSodaOrangeSherbet {type = "trade_items";buy[] = {4000,"Coins"};sell[] = {2000,"Coins"};};
};
//Packaged Food
class Category_635 {
	class FoodCanBakedBeans {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class FoodCanFrankBeans {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class FoodCanPasta {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class FoodCanSardines {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class FoodMRE {type = "trade_items";buy[] = {800,"Coins"};sell[] = {800,"Coins"};};
	class FoodPistachio {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
	class FoodNutmix {type = "trade_items";buy[] = {250,"Coins"};sell[] = {250,"Coins"};};
};
//
