class Category_693 {
	class ItemKiloHemp {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {2000,"Coins"};};
	class ItemMorphine {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {500,"Coins"};};
	class ItemPainkiller {type = "trade_items";buy[] = {500,"Coins"};sell[] = {500,"Coins"};};
};

class Category_695 {
	class ItemObsidian {type = "trade_items";buy[] = {10000,"Coins"};sell[] = {10000,"Coins"};};
	class ItemSapphire {type = "trade_items";buy[] = {10000,"Coins"};sell[] = {10000,"Coins"};};	
	class ItemTopaz {type = "trade_items";buy[] = {10000,"Coins"};sell[] = {10000,"Coins"};};
	class ItemRuby {type = "trade_items";buy[] = {10000,"Coins"};sell[] = {10000,"Coins"};};
	class ItemEmerald {type = "trade_items";buy[] = {9999999,"Coins"};sell[] = {50000,"Coins"};};
};
