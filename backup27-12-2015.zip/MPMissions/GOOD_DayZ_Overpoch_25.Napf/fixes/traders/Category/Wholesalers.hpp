class Category_675 {
	class 30m_plot_kit {type = "trade_items";buy[] = {200000,"Coins"};sell[] = {50000,"Coins"};};
	class ItemLetter {type = "trade_items";buy[] = {300000,"Coins"};sell[] = {100000,"Coins"};};
	class ItemCitrine {type = "trade_items";buy[] = {100000,"Coins"};sell[] = {50000,"Coins"};};
	class ItemAmethyst {type = "trade_items";buy[] = {50000,"Coins"};sell[] = {25000,"Coins"};};
	class ItemBook3 {type = "trade_items";buy[] = {300000,"Coins"};sell[] = {100000,"Coins"};};
	class ItemBook4 {type = "trade_items";buy[] = {100000,"Coins"};sell[] = {50000,"Coins"};};
	class ItemFuelBarrelEmpty {type = "trade_items";buy[] = {1000,"Coins"};sell[] = {1000,"Coins"};};
	class ItemComboLock {type = "trade_items";buy[] = {100000,"Coins"};sell[] = {40000,"Coins"};};
	class PartPlywoodPack {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class PartPlankPack {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class ItemWoodWallThird {type = "trade_items";buy[] = {2000,"Coins"};sell[] = {1000,"Coins"};};
	class ItemWoodFloorQuarter {type = "trade_items";buy[] = {3000,"Coins"};sell[] = {1000,"Coins"};};
	class MortarBucket {type = "trade_items";buy[] = {10000,"Coins"};sell[] = {5000,"Coins"};};
	class metal_panel_kit {type = "trade_items";buy[] = {20000,"Coins"};sell[] = {4000,"Coins"};};
	class metal_floor_kit {type = "trade_items";buy[] = {50000,"Coins"};sell[] = {10000,"Coins"};};
	class CinderBlocks {type = "trade_items";buy[] = {10000,"Coins"};sell[] = {5000,"Coins"};};
	class cinder_wall_kit {type = "trade_items";buy[] = {50000,"Coins"};sell[] = {10000,"Coins"};};
	class cinder_door_kit {type = "trade_items";buy[] = {50000,"Coins"};sell[] = {10000,"Coins"};};
	
	class bulk_ItemTankTrap {type = "trade_items";buy[] ={12000,"Coins"};sell[] ={5000,"Coins"};};
	class bulk_ItemWire {type = "trade_items";buy[] ={12000,"Coins"};sell[] ={5000,"Coins"};};
	class bulk_PartGeneric {type = "trade_items";buy[] ={24000,"Coins"};sell[] ={10000,"Coins"};};
	//class bulk_ItemSandbag {type = "trade_items";buy[] ={72000,"Coins"};sell[] ={30000,"Coins"};};
	//class bulk_15Rnd_9x19_M9SD {type = "trade_items";buy[] ={12000,"Coins"};sell[] ={5000,"Coins"};};
	//class bulk_17Rnd_9x19_glock17 {type = "trade_items";buy[] ={6000,"Coins"};sell[] ={2000,"Coins"};};
	//class bulk_30Rnd_556x45_StanagSD {type = "trade_items";buy[] ={12000,"Coins"};sell[] ={5000,"Coins"};};
	//class bulk_30Rnd_9x19_MP5SD {type = "trade_items";buy[] ={12000,"Coins"};sell[] ={5000,"Coins"};};
};
